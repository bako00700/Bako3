package com.guard1981

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var log: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tv(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 16, 0, 8)
        }

        root.addView(tv("حارس 1981", 26f, true))
        root.addView(tv("يرد تلقائيًا بموقعك عند وصول رسالة تحتوي الرمز."))

        val sw = Switch(this).apply {
            text = "الحراسة مفعّلة"; isChecked = prefs.guardOn
            setOnCheckedChangeListener { _, on ->
                prefs.guardOn = on
                if (on) GuardService.start(this@MainActivity) else GuardService.stop(this@MainActivity)
                refresh()
            }
        }
        root.addView(sw)

        root.addView(tv("الرمز"))
        val trig = EditText(this).apply {
            setText(prefs.trigger); inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(trig)

        root.addView(tv("أرقام مسموحة (اختياري، مفصولة بفاصلة). فارغ = أي رقم"))
        val trusted = EditText(this).apply {
            setText(prefs.trusted); inputType = InputType.TYPE_CLASS_PHONE or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(trusted)

        root.addView(Button(this).apply {
            text = "حفظ الإعدادات"
            setOnClickListener {
                prefs.trigger = trig.text.toString(); prefs.trusted = trusted.text.toString()
                Toast.makeText(this@MainActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "منح الصلاحيات"; setOnClickListener { askPermissions() }
        })
        root.addView(Button(this).apply {
            text = "استثناء التطبيق من توفير البطارية"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        })

        status = tv("", 14f).apply { setTextColor(Color.DKGRAY) }
        root.addView(status)
        root.addView(tv("آخر العمليات", 16f, true))
        log = tv("", 12f)
        root.addView(log)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (prefs.guardOn && has(Manifest.permission.ACCESS_FINE_LOCATION)) GuardService.start(this)
        refresh()
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        val bg = Build.VERSION.SDK_INT < 29 || has(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        val ok = has(Manifest.permission.RECEIVE_SMS) && has(Manifest.permission.SEND_SMS) &&
            has(Manifest.permission.ACCESS_FINE_LOCATION) && bg
        status.text = if (ok) "الصلاحيات: مكتملة ✓" else
            "الصلاحيات ناقصة — اضغط «منح الصلاحيات»، ثم اختر للموقع «السماح طوال الوقت»"
        log.text = prefs.logText().ifBlank { "لا توجد عمليات بعد" }
    }

    private fun askPermissions() {
        val need = listOf(
            Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
        ).let { if (Build.VERSION.SDK_INT >= 33) it + Manifest.permission.POST_NOTIFICATIONS else it }
            .filter { !has(it) }
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        askBackground()
    }

    private fun askBackground() {
        if (Build.VERSION.SDK_INT >= 30) {
            Toast.makeText(this, "اختر «السماح طوال الوقت» للموقع", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } else if (Build.VERSION.SDK_INT == 29 && !has(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 1) {
            if (prefs.guardOn && has(Manifest.permission.ACCESS_FINE_LOCATION)) GuardService.start(this)
            askBackground()
        }
        refresh()
    }
}
