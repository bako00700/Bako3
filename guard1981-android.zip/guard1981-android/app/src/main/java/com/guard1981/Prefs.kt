package com.guard1981

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("guard", Context.MODE_PRIVATE)

    var guardOn: Boolean
        get() = sp.getBoolean("on", true)
        set(v) = sp.edit().putBoolean("on", v).apply()

    var trigger: String
        get() = sp.getString("trigger", "1981") ?: "1981"
        set(v) = sp.edit().putString("trigger", v.trim()).apply()

    /** أرقام مسموحة (مفصولة بفواصل). فارغ = أي رقم (مثل نسخة الويب). */
    var trusted: String
        get() = sp.getString("trusted", "") ?: ""
        set(v) = sp.edit().putString("trusted", v).apply()

    fun isAllowed(from: String): Boolean {
        val list = trusted.split(',', '،', '\n').map { digits(it) }.filter { it.isNotEmpty() }
        if (list.isEmpty()) return true
        val f = digits(from)
        return list.any { it.takeLast(9) == f.takeLast(9) }
    }

    fun log(kind: String, from: String, note: String) {
        val time = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val line = "$time  $kind  $from  $note".replace("\n", " ")
        val old = (sp.getString("log", "") ?: "").split("\n").filter { it.isNotBlank() }
        sp.edit().putString("log", (listOf(line) + old).take(40).joinToString("\n")).apply()
    }

    fun logText(): String = sp.getString("log", "") ?: ""

    private fun digits(s: String) = Sms.normalizeDigits(s).filter { it.isDigit() }
}
