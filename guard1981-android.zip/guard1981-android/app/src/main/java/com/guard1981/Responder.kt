package com.guard1981

import android.content.Context
import android.os.PowerManager
import android.telephony.SmsManager

object Responder {
    /** يحدد الموقع ويرسل الرد. يُبقي المعالج مستيقظًا أثناء العمل حتى والشاشة مغلقة. */
    fun handle(ctx: Context, from: String, timeoutMs: Long, done: () -> Unit) {
        val app = ctx.applicationContext
        val prefs = Prefs(app)
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "guard1981:reply")
        wl.acquire(timeoutMs + 15_000)

        fun finish() {
            if (wl.isHeld) wl.release()
            done()
        }

        try {
            Locator.fix(app, timeoutMs) { loc ->
                try {
                    if (loc == null) {
                        prefs.log("فشل", from, "تعذر تحديد الموقع")
                    } else {
                        val text = Sms.compose(loc)
                        val sm = if (android.os.Build.VERSION.SDK_INT >= 31)
                            app.getSystemService(SmsManager::class.java)
                        else @Suppress("DEPRECATION") SmsManager.getDefault()
                        sm.sendMultipartTextMessage(from, null, sm.divideMessage(text), null, null)
                        prefs.log("تم الرد", from, "±${Math.round(loc.accuracy)} م")
                    }
                } catch (e: Exception) {
                    prefs.log("فشل", from, e.javaClass.simpleName)
                } finally {
                    finish()
                }
            }
        } catch (e: Exception) {
            prefs.log("فشل", from, e.javaClass.simpleName)
            finish()
        }
    }
}
