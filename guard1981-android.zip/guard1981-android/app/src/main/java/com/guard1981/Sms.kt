package com.guard1981

import android.location.Location
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Sms {
    private const val EASTERN = "٠١٢٣٤٥٦٧٨٩"
    private const val PERSIAN = "۰۱۲۳۴۵۶۷۸۹"

    fun normalizeDigits(s: String): String = buildString {
        for (c in s) {
            val e = EASTERN.indexOf(c)
            val p = PERSIAN.indexOf(c)
            append(if (e >= 0) '0' + e else if (p >= 0) '0' + p else c)
        }
    }

    fun containsTrigger(body: String, trigger: String): Boolean {
        val needle = normalizeDigits(trigger).trim()
        return needle.isNotEmpty() && normalizeDigits(body).contains(needle)
    }

    fun compose(loc: Location): String {
        val lat = String.format(Locale.US, "%.6f", loc.latitude)
        val lng = String.format(Locale.US, "%.6f", loc.longitude)
        val lines = mutableListOf("حارس 1981 — الموقع الحالي", "$lat, $lng")
        if (loc.hasAccuracy()) lines.add("دقة ±${Math.round(loc.accuracy)} م")
        lines.add(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(loc.time)))
        lines.add("https://maps.google.com/?q=$lat,$lng")
        return lines.joinToString("\n")
    }
}
