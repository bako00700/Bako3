package com.guard1981

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicBoolean

object Locator {
    /** يجلب موقعًا حديثًا خلال المهلة، وإلا يرجع آخر موقع معروف، وإلا null. */
    @SuppressLint("MissingPermission")
    fun fix(ctx: Context, timeoutMs: Long, done: (Location?) -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val main = Handler(Looper.getMainLooper())
        val finished = AtomicBoolean(false)
        val cancel = CancellationSignal()

        fun lastKnown(): Location? = try {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
        } catch (e: SecurityException) { null }

        fun finish(loc: Location?) {
            if (finished.compareAndSet(false, true)) {
                cancel.cancel()
                done(loc ?: lastKnown())
            }
        }

        val provider = when {
            runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false) -> LocationManager.GPS_PROVIDER
            runCatching { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false) -> LocationManager.NETWORK_PROVIDER
            else -> { finish(null); return }
        }

        main.postDelayed({ finish(null) }, timeoutMs)

        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, cancel, ctx.mainExecutor) { finish(it) }
            } else {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(l: Location) = finish(l)
                    @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                }, Looper.getMainLooper())
            }
        } catch (e: SecurityException) {
            finish(null)
        }
    }
}
