package com.guard1981

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val from = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val prefs = Prefs(ctx)
        if (!prefs.guardOn) return
        if (!Sms.containsTrigger(body, prefs.trigger)) return   // رسائل أخرى: لا تُسجَّل ولا تُقرأ
        if (!prefs.isAllowed(from)) {
            prefs.log("تجاهل", from, "رقم غير مصرح")
            return
        }

        // الخدمة تعمل في الواجهة الأمامية → مهلة أطول لالتقاط GPS (الشاشة مغلقة)
        if (GuardService.running) {
            try {
                ctx.startService(Intent(ctx, GuardService::class.java).putExtra("from", from))
                return
            } catch (e: Exception) { /* نكمل بالمسار الاحتياطي */ }
        }

        // مسار احتياطي: المستقبِل نفسه (حد ~10 ثوانٍ)
        val pending = goAsync()
        Responder.handle(ctx, from, 8000) { pending.finish() }
    }
}
